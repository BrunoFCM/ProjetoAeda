var searchData=
[
  ['addcard',['addCard',['../class_user.html#acb36cb897acf2ec037464d4287bd6fad',1,'User']]],
  ['addgame',['addGame',['../class_system.html#ae6a4e4de154fe101279e69e98a44fa66',1,'System']]],
  ['addsession',['addSession',['../class_game.html#a58b609f7298703487885b48ffcfb6d08',1,'Game::addSession()'],['../class_online.html#a4b41aaac0f7730b51e5c860d86800077',1,'Online::addSession()'],['../class_user.html#a2993d2afdded9990df298ee0d3b401a9',1,'User::addSession()']]],
  ['addtolibrary',['addToLibrary',['../class_user.html#ada76566283ddee73405cc77db2e25b31',1,'User']]],
  ['addupdate',['addUpdate',['../class_game.html#a0cea276d03b13cba1d3f143e505c33b7',1,'Game::addUpdate()'],['../class_home.html#a0aab1d099ede52e4a8ad6115658b99a7',1,'Home::addUpdate()']]],
  ['adduser',['addUser',['../class_game.html#a641ce67a75861ff9355133bc496fd45b',1,'Game::addUser()'],['../class_system.html#a24caca99523a5e08ffb24ca6dcc6dc63',1,'System::addUser()']]]
];
