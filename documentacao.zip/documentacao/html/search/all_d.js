var searchData=
[
  ['searchgame',['searchGame',['../class_system.html#aaa306f38f520be88909a36f4c1856c5a',1,'System::searchGame(unsigned int id)'],['../class_system.html#a35a9d5362df27872ea464e7cf6fd89b8',1,'System::searchGame(string title)']]],
  ['searchuser',['searchUser',['../class_system.html#af076bd104ab125d32786b38d58d0f31c',1,'System']]],
  ['setbalance',['setBalance',['../class_card.html#a9a19e9f3197ebe1ab4f2b052e7aa5562',1,'Card']]],
  ['setnumber',['setNumber',['../class_card.html#aae94436bdf5dc356e6b4db0c5c7188f7',1,'Card']]],
  ['sortgames',['sortGames',['../class_system.html#af7d6c125301f02a7bfe2c89f6d41ae42',1,'System']]],
  ['sortusers',['sortUsers',['../class_system.html#a8c886624c1dab4a15f419e4c66bdbe9e',1,'System']]],
  ['system',['System',['../class_system.html',1,'System'],['../class_system.html#ae317936c9bcf1374d61745572e0f2f8a',1,'System::System()'],['../class_system.html#a8fc11a2b3a11e985512de6499296b105',1,'System::System(ifstream &amp;file)']]]
];
