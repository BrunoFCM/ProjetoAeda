var searchData=
[
  ['repeatedcard',['RepeatedCard',['../class_repeated_card.html',1,'RepeatedCard'],['../class_repeated_card.html#a3a9d08b221cba49860ebfdbc953cd52b',1,'RepeatedCard::RepeatedCard()']]],
  ['repeatedgame',['RepeatedGame',['../class_repeated_game.html',1,'RepeatedGame'],['../class_repeated_game.html#aefbec591911645ea7f82ad4ef1edd75e',1,'RepeatedGame::RepeatedGame()']]],
  ['repeateduser',['RepeatedUser',['../class_repeated_user.html',1,'RepeatedUser'],['../class_repeated_user.html#a1fcc0f0b419021a8601dde840be26ea1',1,'RepeatedUser::RepeatedUser()']]],
  ['restrictgames',['restrictGames',['../class_system.html#ac1d6ba92c951913c738ef83e039bf118',1,'System']]],
  ['restrictusers',['restrictUsers',['../class_system.html#ae225fc012d15479a623b4f0f2de33d23',1,'System']]],
  ['reverttoprice',['revertToPrice',['../class_game.html#aa87df8bd9e09e6e0752ebc000fd1acdc',1,'Game']]]
];
